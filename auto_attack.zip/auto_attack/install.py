import os
import sys

os.system('apt-get install figlet -y')